import { PrismaClient } from '@prisma/client'

const prisma = new PrismaClient()

async function main() {
    const email = 'jorqueramarioalberto@gmail.com'
    const user = await prisma.user.findUnique({
        where: { email },
        include: { workspace: true }
    })

    console.log('USER_CHECK:', JSON.stringify(user, null, 2))
}

main().finally(() => prisma.$disconnect())
