import { Router } from 'express'
import { authenticate } from '../../middleware/auth'
import { requirePlan } from '../../middleware/planGate'
import {
  telegramWebhook,
  whatsappWebhookVerify,
  whatsappWebhook,
  instagramWebhookVerify,
  instagramWebhook,
  messengerWebhookVerify,
  messengerWebhook,
  getConversationsHandler,
  getMessagesHandler,
  sendMessageHandler,
  getChannelsHandler,
  upsertChannelConfigHandler
} from './messaging.controller'

const router = Router()

// Public webhooks — no JWT, identified by workspaceId in URL
router.post('/webhooks/telegram/:workspaceId', telegramWebhook)
router.get('/webhooks/whatsapp/:workspaceId', whatsappWebhookVerify)
router.post('/webhooks/whatsapp/:workspaceId', whatsappWebhook)
router.get('/webhooks/instagram/:workspaceId', instagramWebhookVerify)
router.post('/webhooks/instagram/:workspaceId', instagramWebhook)
router.get('/webhooks/messenger/:workspaceId', messengerWebhookVerify)
router.post('/webhooks/messenger/:workspaceId', messengerWebhook)

// Authenticated inbox routes — PRO and SCALE plans only
router.get('/messaging/channels', authenticate, requirePlan('PRO', 'SCALE'), getChannelsHandler)
router.post('/messaging/channels/:platform/config', authenticate, requirePlan('PRO', 'SCALE'), upsertChannelConfigHandler)
router.get('/messaging/conversations', authenticate, requirePlan('PRO', 'SCALE'), getConversationsHandler)
router.get('/messaging/conversations/:conversationId/messages', authenticate, requirePlan('PRO', 'SCALE'), getMessagesHandler)
router.post('/messaging/conversations/:conversationId/messages', authenticate, requirePlan('PRO', 'SCALE'), sendMessageHandler)

export default router
